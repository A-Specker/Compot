%% color reconstruction

close all;
clear all;
clc;

% here load the images



% call the gui with the loaded images
my_gui(Ir, Ig, Ib);
